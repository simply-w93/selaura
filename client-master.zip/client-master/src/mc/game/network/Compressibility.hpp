#pragma once

enum class Compressibility : int {
    Compressible = 0,
    Incompressible = 1,
};