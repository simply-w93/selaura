#include "scan_target.hpp"

#ifdef SELAURA_WINDOWS
#include "patterns/win/patterns.hpp"
#elif SELAURA_LINUX

#endif