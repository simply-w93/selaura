<h1 align="center">
Selaura Lite
</h1>
<p align="center">
 <a href="https://selauraclient.com/discord" target="_blank">Discord</a>
 •
 <a href="https://selauraclient.com/" target="_blank">Website</a>
 •
 <a href="https://docs.selauraclient.com/" target="_blank">Scripting Documentation</a>
</p>

This repository contains the full source code for Selaura Lite. Selaura Lite is a texturepack that aims to improve user experience of Minecraft: Bedrock Edition with similar features to [Selaura Client](https://github.com/selauraclient/client).

## 🖥️ Compatibility
Selaura Lite currently supports:
- All platforms Minecraft: Bedrock Edition supports.

## 📈 Star History
[![Star History Chart](https://api.star-history.com/svg?repos=selauraclient/lite&type=Date)](https://www.star-history.com/#selauraclient/lite&Date)

## 📄 License
Selaura Lite currently falls under the [GPL-3.0 License](LICENSE). Feel free to use this code as a fork in your own project. Thank you!